"""STEP 1 - dopamine_factory.py : creates a fresh, untrained dopamine .bin

Usage:
  python dopamine_factory.py
  python dopamine_factory.py --inputs 64 --outputs 8 --hidden 100 --out dopamine.bin
"""
import os
import sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "not run"))  # shared code lives here
import argparse
from dopamine_net import DopamineNet
import binfile

ap = argparse.ArgumentParser()
ap.add_argument("--inputs", type=int, default=64, help="input neurons")
ap.add_argument("--outputs", type=int, default=8, help="output neurons")
ap.add_argument("--hidden", type=int, default=100, help="hidden neurons")
ap.add_argument("--density", type=float, default=0.15, help="connection density")
ap.add_argument("--out", default=os.path.join(HERE, "dopamine.bin"))
ap.add_argument("--force", action="store_true", help="overwrite existing file")
a = ap.parse_args()

if os.path.exists(a.out) and not a.force:
    sys.exit("%s already exists (it may hold learned state). Use --force to overwrite." % a.out)

net = DopamineNet.create(a.inputs, a.outputs, a.hidden, a.density)
binfile.save(net, a.out)
print("Created %s" % a.out)
print("  input size : %d" % net.n_in)
print("  output size: %d" % net.n_out)
print("  neurons    : %d" % net.n)
print("  synapses   : %d" % int(net.mask.sum()))
print("  file size  : %.1f KB" % (os.path.getsize(a.out) / 1024))
print("Next: python dopamine_trainer.py")
