"""test.py - checks that the network behaves like dopamine. Never touches dopamine.bin.

Run:  python test.py          (from the factoryD folder, or anywhere)

Tests
  1. Reward prediction error  (expected reward -> ~0, missed reward -> dip, bonus -> spike)
  2. No reward = no learning
  3. Learning, then the rules CHANGE and it has to re-adapt
  4. Save / reload keeps everything, and a corrupt file is rejected
"""
import os
import sys
import tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "not run"))  # shared code lives here

import numpy as np
from dopamine_net import DopamineNet
import binfile
import dopamine_task as task

N_IN, N_OUT = 64, 8
results = []


def check(name, ok, detail=""):
    print("  [%s] %s %s" % ("PASS" if ok else "FAIL", name, detail))
    results.append(bool(ok))


def bar(v, width=20):
    """Text bar for a dopamine value between -1 and +1."""
    n = int(round(min(abs(v), 1.0) * width))
    return ("+" * n).ljust(width) if v >= 0 else ("-" * n).rjust(width)


# ---------------------------------------------------------------- 1
print("\n1. Reward prediction error (the classic dopamine experiment)")
net = DopamineNet.create(N_IN, N_OUT, 100)
x = task.make_pattern(0, N_IN, N_OUT)


def trial(r):
    net.run_trial(x)
    return net.reward(r)


da = [trial(1.0) for _ in range(100)]            # same reward, every time
print("   reward = 1 every trial:")
for t in (1, 5, 20, 50, 100):
    print("     trial %3d  dopamine %+.2f  %s" % (t, da[t - 1], bar(da[t - 1])))
d_miss = trial(0.0)                              # expected reward is MISSING
d_bonus = trial(2.0)                             # reward is BIGGER than expected
print("   reward missing  -> dopamine %+.2f  %s" % (d_miss, bar(d_miss)))
print("   reward doubled  -> dopamine %+.2f  %s" % (d_bonus, bar(d_bonus)))
check("surprise reward gives a big spike", da[0] > 0.9, "(%+.2f)" % da[0])
check("expected reward gives ~0", abs(da[-1]) < 0.1, "(%+.2f)" % da[-1])
check("missing reward gives a dip", d_miss < -0.8, "(%+.2f)" % d_miss)
check("bigger reward gives a spike", d_bonus > 0.5, "(%+.2f)" % d_bonus)

# ---------------------------------------------------------------- 2
print("\n2. No reward = no learning")
net = DopamineNet.create(N_IN, N_OUT, 100)
w0, e0 = net.W.copy(), net.expected
for k in range(200):
    net.run_trial(task.make_pattern(k % N_OUT, N_IN, N_OUT))   # never call reward()
check("weights unchanged", np.array_equal(w0, net.W))
check("expected reward unchanged", net.expected == e0)

# ---------------------------------------------------------------- 3
print("\n3. Learn, then the rules change (re-adaptation)")
net = DopamineNet.create(N_IN, N_OUT, 100)
rng = np.random.default_rng()


def run(shift, trials):
    """Correct action for pattern k is (k + shift) % 8. Returns accuracy."""
    ok = 0
    for _ in range(trials):
        k = int(rng.integers(N_OUT))
        counts = net.run_trial(task.make_pattern(k, N_IN, N_OUT))
        a = int(np.argmax(counts + rng.random(N_OUT) * 1e-3))
        r = 1.0 if a == (k + shift) % N_OUT else 0.0
        net.reward(r)
        ok += int(r)
    return ok / trials


chance = 100.0 / N_OUT
print("   chance = %.1f%%" % chance)
p1 = [run(0, 300) for _ in range(10)]
print("   rule A (pattern k -> action k):")
print("     " + " ".join("%3d%%" % (a * 100) for a in p1))
p2 = [run(3, 300) for _ in range(14)]
print("   rule B (pattern k -> action k+3), switched with no warning:")
print("     " + " ".join("%3d%%" % (a * 100) for a in p2))
a1, a2 = max(p1) * 100, max(p2[4:]) * 100
check("learned rule A", a1 > 3 * chance, "(best round: %.0f%%)" % a1)
check("dropped when rule changed", p2[0] < max(p1) - 0.1,
      "(first round after change: %.0f%%)" % (p2[0] * 100))
check("re-adapted to rule B (above 2x chance)", a2 > 2 * chance,
      "(best round after settling: %.0f%%)" % a2)
print("   info: full recovery (above 3x chance): %s"
      % ("YES" if a2 > 3 * chance else "NO (relearning can be weaker than first learning)"))

# ---------------------------------------------------------------- 4
print("\n4. Save / reload")
path = os.path.join(tempfile.mkdtemp(), "test.bin")
binfile.save(net, path)
back = binfile.load(path)
same = all(np.array_equal(getattr(net, n), getattr(back, n))
           for n in ("V", "theta", "rate", "W", "E", "mask"))
check("all arrays identical after reload", same)
check("expected reward + steps kept",
      abs(net.expected - back.expected) < 1e-6 and net.steps == back.steps)
with open(path, "r+b") as f:
    f.truncate(os.path.getsize(path) - 100)
try:
    binfile.load(path)
    check("corrupt file rejected", False)
except ValueError:
    check("corrupt file rejected", True)

# ---------------------------------------------------------------- done
print("\n%d/%d checks passed" % (sum(results), len(results)))
if not all(results):
    print("(Learning has randomness. A FAIL in test 3 can be a bad random start: run it again.)")
sys.exit(0 if all(results) else 1)
