"""test_chat.py - type to the dopamine network and see what it FEELS.

Run:   python test_chat.py          (talk to it yourself)
       python test_chat.py --demo   (watch a scripted example, no typing)
Type   quit   to leave.   /stats  /reset  /help  also work.

How a turn works
  1. The network says something. It can only pick 1 of 8 reply STYLES,
     so the sentence shown is a canned line for that style.
  2. YOU type a reaction.
  3. feel() reads your words and makes a reward (-1 .. +1).
  4. dopamine = reward - expected reward. That is what it "feels",
     and it learns from it.
  5. It reads your message (as numbers) and picks its next style.

Its brain is saved to chat_brain.bin (NOT dopamine.bin), so it keeps
learning across sessions. It is a tiny network: with a few dozen
messages it will only learn small habits.
"""
import os
import sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "not run"))  # shared code lives here

import re
import zlib
import numpy as np
from dopamine_net import DopamineNet
import binfile

BRAIN = os.path.join(HERE, "chat_brain.bin")
N_IN, N_OUT, HIDDEN = 64, 8, 100
STYLES = ["greet", "ask a question", "joke", "give advice",
          "comfort", "be brief", "explain in detail", "change topic"]
CANNED = {
    "greet": "Hey there! How's it going?",
    "ask a question": "Interesting. What made you say that?",
    "joke": "Why don't scientists trust atoms? They make up everything!",
    "give advice": "If I were you, I'd take it one step at a time.",
    "comfort": "That sounds hard. I'm here with you.",
    "be brief": "Got it.",
    "explain in detail": "Let me explain properly: it works in a few stages...",
    "change topic": "Anyway, did you see the weather today?",
}
POS = {"thanks", "thank", "great", "haha", "funny", "lol", "love", "nice", "good",
       "awesome", "cool", "helpful", "perfect", "yes", "wow", "amazing", "better", "happy"}
NEG = {"no", "wrong", "stop", "annoying", "bad", "hate", "boring", "worse", "ugh",
       "useless", "stupid", "rude", "sad", "terrible", "nope", "shut", "awful"}
NEGATORS = {"not", "never", "don't", "dont", "isn't", "isnt", "wasn't", "wasnt",
            "can't", "cant", "didn't", "didnt"}
rng = np.random.default_rng()


# ---------------------------------------------------------------- feelings
def read_words(text):
    """Find positive / negative words. 'not funny' flips 'funny'."""
    pos, neg, flip = [], [], 0
    for w in re.findall(r"[a-z']+", text.lower()):
        if w in NEGATORS:
            flip = 2                                # flips the next 2 words
            continue
        if w in POS:
            (neg if flip else pos).append(("not " if flip else "") + w)
        elif w in NEG:
            (pos if flip else neg).append(("not " if flip else "") + w)
        flip = max(flip - 1, 0)
    return pos, neg


def feel(text):
    """Return (reward, positive words, negative words, used_but)."""
    before, sep, after = text.lower().partition(" but ")
    if not sep:
        p, n = read_words(text)
        return float(np.clip(len(p) - len(n), -1, 1)), p, n, False
    pb, nb = read_words(before)
    pa, na = read_words(after)
    r = 0.3 * (len(pb) - len(nb)) + 1.0 * (len(pa) - len(na))   # after "but" counts more
    return float(np.clip(r, -1, 1)), pb + pa, nb + na, True


def describe(da):
    if da > 0.6:
        return "big spike! Much better than I expected."
    if da > 0.2:
        return "a pleasant surprise."
    if da >= -0.2:
        return "about what I expected. Nothing changes."
    if da >= -0.6:
        return "disappointed. Worse than I expected."
    return "sharp dip. That hurt."


def fmt(v):
    """+0.25 style number, never '-0.00'."""
    return "%+.2f" % (0.0 if abs(v) < 0.005 else v)


def bar(v, width=10):
    n = int(round(min(abs(v), 1.0) * width))
    return ("+" * n) if v >= 0 else ("-" * n)


# ---------------------------------------------------------------- the brain
def encode(text, k=8):
    """Hashed bag of words -> sparse 0/1 pattern over the input neurons."""
    votes = np.zeros(N_IN)
    for w in re.findall(r"[a-z']+", text.lower()) or ["hello"]:
        for i in range(8):
            votes[zlib.crc32(("%s%d" % (w, i)).encode()) % N_IN] += 1
    x = np.zeros(N_IN, np.float32)
    x[np.argsort(-votes, kind="stable")[:k]] = 1.0
    return x


def choose(net, text):
    counts = net.run_trial(encode(text))
    if counts.max() == 0:
        return int(rng.integers(N_OUT))             # nothing fired: explore
    return int(np.argmax(counts + rng.random(N_OUT) * 1e-3))


def new_brain():
    return DopamineNet.create(N_IN, N_OUT, HIDDEN)


def say(style):
    print('\nBrain [%s]> "%s"' % (style, CANNED[style]))


DEMO = ["haha thanks, that was funny", "no stop, that is annoying",
        "ok", "thanks but no", "that is not funny", "great, I love it"]


def main():
    demo = "--demo" in sys.argv
    if demo or not os.path.exists(BRAIN):
        net = new_brain()
        print("Started a fresh brain%s." % (" (demo: not saved)" if demo else ""))
    else:
        net = binfile.load(BRAIN)
        print("Loaded %s (%d steps of experience)." % (os.path.basename(BRAIN), net.steps))
    print("Type a reaction to what it says. 'quit' to leave, /help for more.")

    tally = {s: [0, 0.0] for s in STYLES}               # times used, total reward
    style = choose(net, "hello")
    say(STYLES[style])
    lines = iter(DEMO)
    turns = 0
    while True:
        try:
            if demo:
                text = next(lines)
                print("\nYou> " + text)
            else:
                text = input("\nYou> ")
        except (EOFError, StopIteration):
            break
        text = text.strip()
        if text.lower() in ("quit", "exit", "q"):
            break
        if not text:
            continue
        if text == "/help":
            print("  quit = leave (saves)   /stats = what each style earned   /reset = new brain")
            continue
        if text == "/stats":
            print("  style               used   avg reward")
            for s in STYLES:
                n, tot = tally[s]
                print("  %-18s %4d   %s" % (s, n, ("%+.2f" % (tot / n)) if n else "  -"))
            continue
        if text == "/reset":
            net = new_brain()
            tally = {s: [0, 0.0] for s in STYLES}
            print("  Fresh brain. It forgot everything.")
            style = choose(net, "hello")
            say(STYLES[style])
            continue

        # --- what it feels about the style it just used
        r, p, n, used_but = feel(text)
        exp_before = net.expected
        da = net.reward(r)                  # once per trial, before the next run_trial
        tally[STYLES[style]][0] += 1
        tally[STYLES[style]][1] += r
        turns += 1
        print("\n  I counted:  + %s   - %s" % (", ".join(p) or "none", ", ".join(n) or "none"))
        if used_but:
            print("              (after 'but' counts more)")
        print("  reward    %s   (I expected %s)" % (fmt(r), fmt(exp_before)))
        print("  dopamine  %s   %s" % (fmt(da), bar(da)))
        print("  feeling:  %s" % describe(da))
        change = ("got stronger" if da > 0.05 else
                  "got weaker" if da < -0.05 else "stayed the same")
        print("  learned:  the '%s' habit %s" % (STYLES[style], change))

        style = choose(net, text)           # read the message, pick the next style
        say(STYLES[style])
        if turns % 10 == 0 and not demo:
            binfile.save(net, BRAIN)

    if not demo:
        binfile.save(net, BRAIN)
        print("\nSaved brain to %s" % os.path.basename(BRAIN))
    print("Bye.")


if __name__ == "__main__":
    main()
