"""binfile.py - saves/loads the whole network as ONE .bin file.

Layout:
  header : magic 'DOPA', version, n_total, n_in, n_out, steps (uint64),
           expected_reward (float32), then one float32 per PARAM_NAMES
  arrays : V, theta, rate (float32 x n), W, E (float32 x n*n), mask (uint8 x n*n)
"""
import os
import struct
import numpy as np
from dopamine_net import DopamineNet, PARAM_NAMES

MAGIC = b"DOPA"
VERSION = 1
HEAD = "<4sIIIIQf"
HEAD_SIZE = struct.calcsize(HEAD)
PARAMS_FMT = "<%df" % len(PARAM_NAMES)


def save(net, path):
    with open(path, "wb") as f:
        f.write(struct.pack(HEAD, MAGIC, VERSION, net.n, net.n_in,
                            net.n_out, net.steps, net.expected))
        f.write(struct.pack(PARAMS_FMT, *[net.params[k] for k in PARAM_NAMES]))
        for a in (net.V, net.theta, net.rate, net.W, net.E):
            f.write(a.astype("<f4").tobytes())
        f.write(net.mask.astype("u1").tobytes())


def read_header(path):
    with open(path, "rb") as f:
        raw = f.read(HEAD_SIZE)
    magic, ver, n, n_in, n_out, steps, expected = struct.unpack(HEAD, raw)
    if magic != MAGIC:
        raise ValueError("Not a dopamine .bin file")
    if ver != VERSION:
        raise ValueError("Unsupported version %d" % ver)
    return dict(n=n, n_in=n_in, n_out=n_out, steps=steps, expected=expected)


def load(path):
    h = read_header(path)
    n = h["n"]
    p_size = struct.calcsize(PARAMS_FMT)
    expect = HEAD_SIZE + p_size + 4 * (3 * n + 2 * n * n) + n * n
    if os.path.getsize(path) != expect:
        raise ValueError("File size does not match its header (corrupt?)")
    with open(path, "rb") as f:
        f.seek(HEAD_SIZE)
        vals = struct.unpack(PARAMS_FMT, f.read(p_size))
        net = DopamineNet(h["n_in"], h["n_out"], n, dict(zip(PARAM_NAMES, vals)))
        net.steps, net.expected = h["steps"], h["expected"]
        rd = lambda c, shape: np.frombuffer(
            f.read(c * 4), "<f4").astype(np.float32).reshape(shape)
        net.V, net.theta, net.rate = rd(n, n), rd(n, n), rd(n, n)
        net.W, net.E = rd(n * n, (n, n)), rd(n * n, (n, n))
        net.mask = np.frombuffer(f.read(n * n), "u1").reshape(n, n).copy()
    return net
