"""dopamine_task.py - a simple reward task used by the trainer and tester.

There are n_out patterns. Pattern k lights up input block k.
The correct action for pattern k is output neuron k.
Reward = 1 if the net picked the right one, else 0.
"""
import numpy as np


def make_pattern(k, n_in, n_out):
    x = np.zeros(n_in, np.float32)
    size = n_in // n_out
    x[k * size:(k + 1) * size] = 1.0
    return x


def run(net, trials, learn, restructure_every=0):
    """Run `trials` trials. Returns (accuracy, mean_dopamine)."""
    rng = np.random.default_rng()
    correct, da_sum = 0, 0.0
    for t in range(trials):
        k = int(rng.integers(net.n_out))
        counts = net.run_trial(make_pattern(k, net.n_in, net.n_out))
        # pick the most active output; random tie-break
        action = int(np.argmax(counts + rng.random(net.n_out) * 1e-3))
        r = 1.0 if action == k else 0.0
        correct += int(r)
        if learn:
            da_sum += net.reward(r)
            if restructure_every and (t + 1) % restructure_every == 0:
                net.restructure()
    return correct / trials, da_sum / max(trials, 1)
