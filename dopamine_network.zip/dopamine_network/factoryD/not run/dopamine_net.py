"""dopamine_net.py - the dopamine-style spiking network (shared by all steps)."""
import numpy as np

# Order matters: this is the order saved in the .bin header.
PARAM_NAMES = [
    "leak", "input_gain", "noise", "theta_init", "theta_min", "theta_rate",
    "target_rate", "trace_decay", "learning_rate", "rpe_rate", "w_max",
    "prune_below", "grow_prob", "out_inhibit",
]
DEFAULT_PARAMS = {
    "leak": 0.8,            # membrane potential decay per step
    "input_gain": 1.5,      # current given to an active input neuron
    "noise": 0.15,          # random noise (lets the net explore actions)
    "theta_init": 1.0,      # starting firing threshold
    "theta_min": 0.2,       # thresholds never drop below this
    "theta_rate": 0.002,    # how fast thresholds adapt
    "target_rate": 0.1,     # firing rate each neuron "wants"
    "trace_decay": 0.9,     # eligibility trace fade per step
    "learning_rate": 0.05,  # weight change = lr * dopamine * trace
    "rpe_rate": 0.05,       # how fast expected reward follows actual reward
    "w_max": 1.0,           # weight clip
    "prune_below": 0.01,    # |weight| under this gets pruned
    "grow_prob": 0.005,     # chance a co-active unconnected pair connects
    "out_inhibit": 1.0,     # output neurons suppress each other (winner-take-all)
}
RATE_DECAY = 0.99


class DopamineNet:
    """Layout: [ input neurons | hidden neurons | output neurons ]"""

    def __init__(self, n_in, n_out, n_total, params=None):
        self.n_in, self.n_out, self.n = n_in, n_out, n_total
        self.params = dict(DEFAULT_PARAMS)
        if params:
            self.params.update(params)
        n = n_total
        self.V = np.zeros(n, np.float32)           # membrane potentials
        self.theta = np.full(n, self.params["theta_init"], np.float32)
        self.rate = np.zeros(n, np.float32)        # running firing rate
        self.W = np.zeros((n, n), np.float32)      # W[pre, post]
        self.E = np.zeros((n, n), np.float32)      # eligibility traces
        self.mask = np.zeros((n, n), np.uint8)     # connection map
        self.expected = 0.0                        # expected reward
        self.steps = 0
        self.prev = np.zeros(n, np.float32)
        self.rng = np.random.default_rng()

    @classmethod
    def create(cls, n_in, n_out, n_hidden, density=0.15, params=None):
        net = cls(n_in, n_out, n_in + n_hidden + n_out, params)
        n = net.n
        mask = (net.rng.random((n, n)) < density).astype(np.uint8)
        mask[:, :n_in] = 0                 # nothing connects INTO inputs
        mask[np.arange(n), np.arange(n)] = 0
        net.mask = mask
        net.W = (net.rng.uniform(0.02, 0.15, (n, n)) * mask).astype(np.float32)
        return net

    # ---------- running ----------
    def begin_trial(self):
        self.V[:] = 0
        self.prev[:] = 0
        self.E[:] = 0

    def step(self, inp):
        p = self.params
        cur = np.zeros(self.n, np.float32)
        cur[: self.n_in] = np.asarray(inp, np.float32) * p["input_gain"]
        noise = self.rng.standard_normal(self.n).astype(np.float32) * p["noise"]
        self.V = self.V * p["leak"] + cur + self.prev @ self.W + noise
        po = self.prev[-self.n_out:]
        self.V[-self.n_out:] -= p["out_inhibit"] * (po.sum() - po)
        fired = self.V >= self.theta
        self.V[fired] = 0
        s = fired.astype(np.float32)
        # eligibility: pre fired last step, post fires now
        self.E = self.E * p["trace_decay"] + np.outer(self.prev, s) * self.mask
        # adaptive thresholds (not for input neurons)
        self.rate = RATE_DECAY * self.rate + (1 - RATE_DECAY) * s
        d = p["theta_rate"] * (self.rate - p["target_rate"])
        d[: self.n_in] = 0
        self.theta = np.maximum(self.theta + d, p["theta_min"])
        self.prev = s
        self.steps += 1
        return s

    def run_trial(self, inp, steps=20):
        """Run one trial, return output-neuron spike counts."""
        self.begin_trial()
        counts = np.zeros(self.n_out, np.float32)
        for _ in range(steps):
            counts += self.step(inp)[-self.n_out:]
        return counts

    # ---------- dopamine ----------
    def reward(self, r):
        """Apply reward. dopamine = reward - expected. Returns dopamine."""
        p = self.params
        da = r - self.expected
        self.expected += p["rpe_rate"] * da
        self.W += p["learning_rate"] * da * self.E
        self.W = np.clip(self.W * self.mask, -p["w_max"], p["w_max"])
        return da

    # ---------- structure ----------
    def restructure(self):
        """Prune weak synapses, grow new ones between co-active neurons."""
        p = self.params
        weak = (np.abs(self.W) < p["prune_below"]) & (self.mask == 1)
        self.mask[weak] = 0
        self.W[weak] = 0
        cand = (self.mask == 0) & (self.E > 0.05)
        cand[:, : self.n_in] = False
        new = cand & (self.rng.random(cand.shape) < p["grow_prob"])
        self.mask[new] = 1
        self.W[new] = 0.05
        return int(weak.sum()), int(new.sum())
