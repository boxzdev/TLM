"""STEP 2 - dopamine_trainer.py : loads the .bin, trains it, saves it back

Usage:
  python dopamine_trainer.py
  python dopamine_trainer.py --bin dopamine.bin --rounds 10 --trials 300
Run it again any time to keep training from where it left off.
"""
import os
import sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "not run"))  # shared code lives here
import argparse
import binfile
import dopamine_task as task

ap = argparse.ArgumentParser()
ap.add_argument("--bin", default=os.path.join(HERE, "dopamine.bin"))
ap.add_argument("--rounds", type=int, default=15, help="progress reports")
ap.add_argument("--trials", type=int, default=300, help="trials per round")
ap.add_argument("--restructure", type=int, default=0,
                help="prune/grow synapses every N trials (0 = off, default)")
a = ap.parse_args()

net = binfile.load(a.bin)
print("Loaded %s (steps so far: %d)" % (a.bin, net.steps))

for r in range(1, a.rounds + 1):
    acc, da = task.run(net, a.trials, learn=True, restructure_every=a.restructure)
    print("round %2d  accuracy %5.1f%%  avg dopamine %+.3f  expected reward %.2f"
          % (r, acc * 100, da, net.expected))

binfile.save(net, a.bin)
print("Saved %s (synapses: %d)" % (a.bin, int(net.mask.sum())))
print("Next: python dopamine_tester.py")
