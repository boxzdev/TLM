"""test_maze.py - find a RANDOM goal in a grid full of RANDOM walls.

Run:  python test_maze.py          10x10 grid, ~20% walls (new walls every episode)
      python test_maze.py --easy   7x7 open grid, no walls
(never touches dopamine.bin)

Every episode a new grid is made with random walls (#), and the robot (S) and
the goal (G) are dropped on random free cells. It can only move up, down,
left or right. After EVERY move:
    +1   the move got it closer to the goal (shortest way around the walls)
    -1   it went farther away, or bumped into a wall / the edge   (punishment)
What it senses (it can't see the map, and it can't plan ahead):
    - which direction the goal is in (up, down-left, ...)  = 8 options
    - whether a wall blocks the way toward the goal, up/down and left/right
So it has to learn things like "goal is right -> go right; if right is
blocked -> go up or down instead".
It does not learn from a reward that only comes at the goal (delayed reward).
Learning is noisy, so the test keeps the BEST snapshot seen during training
and restarts with a fresh network (up to 3 attempts) if one never takes off.
"""
import os
import sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "not run"))  # shared code lives here

import copy
from collections import deque
import numpy as np
from dopamine_net import DopamineNet

EASY = "--easy" in sys.argv
SIZE, WALL_P, MAX_STEPS = (7, 0.0, 14) if EASY else (10, 0.2, 30)
TRIAL_STEPS = 12                                 # network steps per move
MOVES = [(-1, 0), (1, 0), (0, -1), (0, 1)]       # up, down, left, right
NAMES = ["up", "down", "left", "right"]
ARROWS = "^v<>"
SIGNS = [(a, b) for a in (-1, 0, 1) for b in (-1, 0, 1) if (a, b) != (0, 0)]
PER_STATE = 8
N_STATES = len(SIGNS) * 4                        # 8 directions x 2 "blocked" flags
N_IN, N_OUT = N_STATES * PER_STATE, 4
rng = np.random.default_rng()


def sign(v):
    return (v > 0) - (v < 0)


def is_free(wall, cell):
    r, c = cell
    return 0 <= r < SIZE and 0 <= c < SIZE and not wall[r, c]


def bfs(wall, goal):
    """Shortest-path distance to the goal from every free cell (-1 = unreachable)."""
    d = np.full((SIZE, SIZE), -1, int)
    d[goal] = 0
    q = deque([goal])
    while q:
        r, c = q.popleft()
        for dr, dc in MOVES:
            n = (r + dr, c + dc)
            if is_free(wall, n) and d[n] < 0:
                d[n] = d[r, c] + 1
                q.append(n)
    return d


def make_world(min_dist=1):
    while True:
        wall = rng.random((SIZE, SIZE)) < WALL_P
        free = np.argwhere(~wall)
        if len(free) < 2:
            continue
        s = tuple(int(v) for v in free[rng.integers(len(free))])
        g = tuple(int(v) for v in free[rng.integers(len(free))])
        if s == g:
            continue
        d = bfs(wall, g)
        if d[s] >= min_dist:
            return wall, s, g, d


def state_of(pos, goal, wall):
    sr, sc = sign(goal[0] - pos[0]), sign(goal[1] - pos[1])
    v_blocked = sr != 0 and not is_free(wall, (pos[0] + sr, pos[1]))
    h_blocked = sc != 0 and not is_free(wall, (pos[0], pos[1] + sc))
    return SIGNS.index((sr, sc)) * 4 + int(v_blocked) * 2 + int(h_blocked)


def encode(state):
    x = np.zeros(N_IN, np.float32)
    x[state * PER_STATE:(state + 1) * PER_STATE] = 1.0
    return x


def choose_state(net, state):
    counts = net.run_trial(encode(state), steps=TRIAL_STEPS)
    if counts.max() == 0:                        # nothing fired: explore
        return int(rng.integers(N_OUT))
    return int(np.argmax(counts + rng.random(N_OUT) * 1e-3))


def episode(net, world, learn, random_policy=False):
    wall, start, goal, d = world
    pos, path = start, []
    for t in range(MAX_STEPS):
        a = int(rng.integers(N_OUT)) if random_policy else choose_state(net, state_of(pos, goal, wall))
        tried = (pos[0] + MOVES[a][0], pos[1] + MOVES[a][1])
        ok = is_free(wall, tried)
        if learn:
            net.reward(1.0 if ok and d[tried] < d[pos] else -1.0)
        path.append((pos, a))
        if ok:
            pos = tried
        if pos == goal:
            return True, t + 1, path
    return False, MAX_STEPS, path


def success_rate(net, n=40):
    return float(np.mean([episode(net, make_world(), False)[0] for _ in range(n)]))


def draw(world, path):
    wall, start, goal, _ = world
    grid = [["#" if wall[r, c] else "." for c in range(SIZE)] for r in range(SIZE)]
    for cell, a in path:
        grid[cell[0]][cell[1]] = ARROWS[a]
    grid[start[0]][start[1]] = "S"
    grid[goal[0]][goal[1]] = "G"
    for row in grid:
        print("      " + " ".join(row))


results = []


def check(name, ok, detail=""):
    print("  [%s] %s %s" % ("PASS" if ok else "FAIL", name, detail))
    results.append(bool(ok))


print("\n%dx%d grid, %d%% walls (new every episode), random start and goal, %d-move limit"
      % (SIZE, SIZE, int(WALL_P * 100), MAX_STEPS))
random_rate = float(np.mean([episode(None, make_world(), False, True)[0] for _ in range(300)]))
print("Random wandering reaches the goal %.0f%% of the time" % (random_rate * 100))

ROUNDS, ATTEMPTS, EPS_PER_ROUND = 8, 3, 20
net = DopamineNet.create(N_IN, N_OUT, 100)
best_net, best_score, used = None, -1.0, 0
for attempt in range(1, ATTEMPTS + 1):
    used = attempt
    if attempt > 1:
        print("   ...never took off, starting over with a fresh network")
        net = DopamineNet.create(N_IN, N_OUT, 100)
    print("\nTraining, attempt %d (reward/punishment after every move):" % attempt)
    att_best = 0.0
    for rnd in range(1, ROUNDS + 1):
        for _ in range(EPS_PER_ROUND):
            episode(net, make_world(), True)
        score = success_rate(net)                  # quick check, learning off
        print("   round %2d  reached the goal %3.0f%%   expected reward %+.2f"
              % (rnd, score * 100, net.expected))
        att_best = max(att_best, score)
        if score > best_score:
            best_score, best_net = score, copy.deepcopy(net)
    if att_best >= 0.5:
        break
net = best_net
print("\nKept the best snapshot (%.0f%% in its quick check, attempt %d of %d)"
      % (best_score * 100, used, ATTEMPTS))

runs = [episode(net, make_world(), False) for _ in range(150)]
after = float(np.mean([r[0] for r in runs]))
print("\nFinal exam (learning off, 150 new grids): reaches the goal %.0f%% of the time" % (after * 100))

# ---- what does it do in an open field, and when a wall is in the way?
def label(sr, sc):
    return ("up" if sr < 0 else "down" if sr > 0 else "") + \
           ("-" if sr and sc else "") + ("left" if sc < 0 else "right" if sc > 0 else "")


print("\nOpen field (nothing in the way):")
print("   goal is...      it moves   right?")
right = 0
for sr, sc in SIGNS:
    votes = np.bincount([choose_state(net, SIGNS.index((sr, sc)) * 4) for _ in range(15)], minlength=N_OUT)
    a = int(np.argmax(votes))
    toward = (sr and MOVES[a] == (sr, 0)) or (sc and MOVES[a] == (0, sc))
    right += bool(toward)
    print("   %-14s  %-8s   %s" % (label(sr, sc), NAMES[a], "yes" if toward else "NO"))

around = 0
if not EASY:
    print("\nWall in the way (goal straight ahead, but blocked):")
    print("   goal is...      it moves   goes around?")
    for sr, sc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        flag = 2 if sr else 1                       # vertical-blocked / horizontal-blocked
        votes = np.bincount([choose_state(net, SIGNS.index((sr, sc)) * 4 + flag) for _ in range(15)],
                            minlength=N_OUT)
        a = int(np.argmax(votes))
        sideways = (MOVES[a][0] == 0) if sr else (MOVES[a][1] == 0)
        around += bool(sideways)
        print("   %-14s  %-8s   %s" % (label(sr, sc), NAMES[a], "yes" if sideways else "NO"))

world = make_world(min_dist=8)
reached, steps, path = episode(net, world, False)
print("\nExample trip (S start, G goal, # wall, arrows = its moves):")
draw(world, path)
print("   %s in %d moves (shortest possible: %d)"
      % ("Reached the goal" if reached else "Did NOT reach the goal", steps, world[3][world[1]]))

print()
need = 0.7 if EASY else 0.5
check("beats random wandering by 30+ points", after > random_rate + 0.30,
      "(%.0f%% vs %.0f%%)" % (after * 100, random_rate * 100))
check("reaches the goal %d%%+ of the time" % (need * 100), after >= need, "(%.0f%%)" % (after * 100))
check("right move for 6 of 8 goal directions", right >= 6, "(%d of 8)" % right)
if not EASY:
    check("goes around a wall in 3 of 4 cases", around >= 3, "(%d of 4)" % around)
print("\n%d/%d checks passed" % (sum(results), len(results)))
if not all(results):
    print("(Learning has randomness. A FAIL can be a bad random start: run it again.)")
sys.exit(0 if all(results) else 1)
