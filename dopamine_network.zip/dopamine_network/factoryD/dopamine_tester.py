"""STEP 3 - dopamine_tester.py : loads the .bin and tests it. Never saves.

Usage:
  python dopamine_tester.py
  python dopamine_tester.py --bin dopamine.bin --trials 200
"""
import os
import sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "not run"))  # shared code lives here
import argparse
import binfile
import dopamine_task as task

ap = argparse.ArgumentParser()
ap.add_argument("--bin", default=os.path.join(HERE, "dopamine.bin"))
ap.add_argument("--trials", type=int, default=200)
a = ap.parse_args()

net = binfile.load(a.bin)
steps_before = net.steps
acc, _ = task.run(net, a.trials, learn=False)
print("File       : %s" % a.bin)
print("Trained for: %d steps" % steps_before)
print("Synapses   : %d" % int(net.mask.sum()))
print("Accuracy   : %.1f%% over %d trials (chance = %.1f%%)"
      % (acc * 100, a.trials, 100.0 / net.n_out))
print("(read-only test: the .bin was not changed)")
