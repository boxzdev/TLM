# Dopamine Network

A small dopamine-style spiking neural network that saves everything it learns into **one `.bin` file**.

Requirements: Python 3 and NumPy (`pip install numpy`).

## Quick start

Unzip, open a terminal in the `factoryD` folder, and run the three steps in order:

```
cd factoryD
python dopamine_factory.py     # 1. create a fresh dopamine.bin
python dopamine_trainer.py     # 2. train it and save it back
python dopamine_tester.py      # 3. test it (read-only)
```

Run step 2 again any time to keep training from where it left off.

## Folder layout

```
dopamine_network/
├── README.md
└── factoryD/                  <- the workflow: run these, in order
    ├── dopamine_factory.py    (step 1)
    ├── dopamine_trainer.py    (step 2)
    ├── dopamine_tester.py     (step 3)
    ├── dopamine.bin           (created by step 1)
    └── not run/               <- shared code, never run directly
        ├── dopamine_net.py
        ├── binfile.py
        └── dopamine_task.py
```

| File | Role |
|---|---|
| `dopamine_factory.py` | **Step 1.** Creates a new, untrained `.bin`. |
| `dopamine_trainer.py` | **Step 2.** Loads the `.bin`, trains, saves it back. |
| `dopamine_tester.py` | **Step 3.** Loads the `.bin`, reports accuracy, never saves. |
| `not run/dopamine_net.py` | The network itself (neurons, synapses, dopamine rule). |
| `not run/binfile.py` | Saves and loads the single `.bin`. |
| `not run/dopamine_task.py` | A simple reward task used by the trainer and tester. |

The `.bin` is saved inside `factoryD` by default, no matter which folder you run the scripts from.

## Options

**Factory**
```
python dopamine_factory.py --inputs 64 --outputs 8 --hidden 100 --density 0.15 --out dopamine.bin
```
It refuses to overwrite an existing file unless you add `--force`.

**Trainer**
```
python dopamine_trainer.py --bin dopamine.bin --rounds 15 --trials 300 --restructure 0
```
`--restructure N` prunes weak synapses and grows new ones every N trials. It is **off by default** (0) because it made learning worse in testing.

**Tester**
```
python dopamine_tester.py --bin dopamine.bin --trials 200
```

## How it works

- **Neurons:** leaky integrate-and-fire. Each has a membrane potential, a firing threshold, and a leak.
- **Synapses:** a weight matrix plus an eligibility trace (a fading memory of "pre fired, then post fired").
- **Dopamine:** `dopamine = reward - expected reward`. The expectation then moves toward the actual reward. A surprise gives a spike, an expected reward gives about zero, a missed reward gives a dip.
- **Learning rule:** `weight change = learning rate x dopamine x eligibility trace`.
- **Adaptive thresholds:** each neuron's threshold drifts to keep its firing rate near a target.
- **Winner-take-all outputs:** output neurons inhibit each other so one action wins.
- **Restructuring (optional):** weak synapses are pruned, and new ones can form between co-active neurons.

Neuron layout: `[ input | hidden | output ]`.

## The demo task

There are 8 patterns. Pattern `k` lights up input block `k`, and the correct action is output neuron `k`. Reward is 1 for the right action, 0 otherwise. Chance level is 12.5%.

## The `.bin` file

One file holds everything:

- **Header:** magic `DOPA`, version, neuron count, input size, output size, step count, expected reward, then the 14 parameters.
- **Arrays:** potentials, thresholds, firing rates, weights, eligibility traces, connection map.

Loading checks the magic, the version, and that the file size matches the header, so a corrupt or wrong file gives a clear error.

## Using it in your own code (API)

For people and AI agents who want to call the network from another script. Everything is in `factoryD/not run/`.

```python
import sys
sys.path.insert(0, "factoryD/not run")      # adjust the path to where you run from
import binfile

net = binfile.load("factoryD/dopamine.bin")  # load the network
counts = net.run_trial(inputs)               # sense -> output spike counts
action = int(counts.argmax())                # the winning output neuron
dopamine = net.reward(r)                     # learn from the result
binfile.save(net, "factoryD/dopamine.bin")   # keep what it learned
```

| Call | What it does |
|---|---|
| `binfile.load(path)` / `binfile.save(net, path)` | Read / write the single `.bin`. |
| `net.n_in`, `net.n_out` | Interface sizes. `inputs` must have length `n_in`; `counts` has length `n_out`. |
| `net.run_trial(inputs, steps=20)` | Runs one trial and returns how many times each output neuron fired. `inputs` is a float vector with values from 0 to 1. |
| `net.reward(r)` | Applies reward `r` (use about -1 to +1) and returns the dopamine value. This is the **only** call that makes it learn. |
| `net.restructure()` | Optional. Prunes weak synapses and grows new ones. Call it right after `reward`. Off by default because it hurt learning in testing. |
| `net.expected`, `net.steps` | Current expected reward, and how many steps it has run. |

**Rules to follow:**
1. Call `reward()` **once per trial, after `run_trial()` and before the next `run_trial()`**. Each new trial clears the eligibility traces, so a late reward would have nothing to credit.
2. No `reward()` call means no learning. Calling only `run_trial()` just uses what it already knows.
3. If `counts` are all zero, no output fired. Pick a random action (this also lets it explore).
4. It chooses one of `n_out` fixed actions. It does not write free text.
5. Save regularly. All learning lives in the `.bin`.

## How reward works

The network does not know what "good" means. Your script decides, and passes a number to `net.reward(r)`.

```
dopamine = reward - expected reward
```

- Better than expected: dopamine is positive, and the connections that were just active get stronger.
- Worse than expected: dopamine is negative, and those connections get weaker.
- Exactly as expected: nothing changes. The expectation then moves toward the actual reward.

A reward of 0 is not neutral. If the network expected +0.8, getting 0 counts as a disappointment and weakens what it just did.

**Reward examples** (the reward rule is the `feel()` / `judge()` function in your script):

| Environment | Input (numbers) | Outputs (actions) | Reward |
|---|---|---|---|
| Answering questions | The question as numbers | 8 answer choices | +1 correct, 0 wrong |
| Talking | The person's message as numbers | 8 reply styles (greet, joke, ask, comfort...) | Computed from the person's reaction, no thumbs needed (see below) |
| Touching | 64 pressure sensors | grip tighter, loosen, release... | +1 held steady, -1 slipped or crushed |

**Automatic reward from a conversation** (no thumbs up or down needed). Possible signals: sentiment of their reply, whether they keep talking, whether they repeat or rephrase themselves (the last answer probably missed), and surprise at what they said. Mixed messages like "thanks but no" cancel out if scored as a whole, so score the part after "but" higher:

```python
import re
import numpy as np

def feel(reply):
    pos = ["thanks", "great", "haha", "funny"]
    neg = ["no", "wrong", "stop", "annoying"]
    def score(t):
        words = set(re.findall(r"[a-z']+", t.lower()))   # whole words only
        return len(words & set(pos)) - len(words & set(neg))
    before, _, after = reply.partition(" but ")
    return float(np.clip(0.3 * score(before) + 1.0 * score(after), -1, 1))

feel("thanks but no")                  # -0.7
feel("so funny but annoying")          # -0.7
```

Keyword lists are crude. For real use, replace `score()` with a small sentiment model or the LLM itself, which can also catch sarcasm. Be careful what you reward: the network chases whatever the rule pays for.

## Combining with an LLM

The `.bin` stays separate from the LLM. A short script links them: the LLM turns the conversation into numbers, the dopamine network picks a *style or strategy*, the LLM writes the reply in that style, and the person's reaction becomes the reward.

```
person's message -> LLM embedding -> adapter -> dopamine net -> style #k
                                                                    |
person's reaction -> feel() -> net.reward(r)        LLM writes reply in style k
```

Working example (tested; replace `embedding` with your LLM's embedding of the latest message):

```python
import numpy as np
import sys
sys.path.insert(0, "factoryD/not run")
import binfile

net = binfile.load("factoryD/dopamine.bin")
STYLES = ["greet", "ask a question", "joke", "give advice",
          "comfort", "be brief", "explain in detail", "change topic"]
assert len(STYLES) == net.n_out                  # one style per output neuron

EMB_DIM = 384                                    # your embedding size
PROJ = np.random.default_rng(12345).standard_normal((EMB_DIM, net.n_in))  # FIXED seed

def to_input(embedding, k=8):
    scores = np.asarray(embedding) @ PROJ
    x = np.zeros(net.n_in, np.float32)
    x[np.argsort(scores)[-k:]] = 1.0             # sparse 0/1 pattern, like the demo
    return x

def choose(embedding):
    counts = net.run_trial(to_input(embedding))
    if counts.max() == 0:
        return int(np.random.randint(net.n_out)) # nothing fired: explore
    return int(np.argmax(counts + np.random.rand(net.n_out) * 1e-3))

# each turn:
k = choose(embedding)
# ... ask the LLM to reply in the style STYLES[k], send it, read the person's reply ...
net.reward(feel(person_reply))
binfile.save(net, "factoryD/dopamine.bin")       # now and then
```

Things that will break it:
- **Changing `PROJ` between runs.** Keep the same seed (or save the matrix). The network learned on that mapping.
- **Dense inputs.** Keep inputs sparse (a few 1s, rest 0), as the demo does. If every input neuron is active, there is no pattern to learn.
- **Size mismatch.** `len(inputs)` must equal `net.n_in`, and the number of actions must equal `net.n_out`. To change the sizes, create a new `.bin` with `dopamine_factory.py --inputs N --outputs M`. An existing `.bin` can't be resized.

In a quick test with a fake person who always liked jokes for one topic, the network went from picking "joke" about 28-64% of the time to 64-100% within 300 turns. Real conversations are noisier, so expect slower and less reliable learning.

## Connecting to another file later

To link this network to another `.bin` (an environment or LLM side), only the **interface sizes** need to match, not the whole file:

- The other side's output size must equal this network's **input size**.
- This network's **output size** must equal what the other side accepts.

Neuron counts and other header fields can differ. If sizes don't line up, use a small adapter in the linking script.

## Known limitations

- Learning works but is **not fully stable**. After training, some runs reach about 90% and others stay around 30-40%, depending on the random start. If a run gets stuck, recreate the file with `python dopamine_factory.py --force` and train again.
- In the demo, the reward comes from `not run/dopamine_task.py`. In your own project, your script supplies the reward (see "How reward works").
- Adult neurogenesis (adding brand-new neurons) is not included. The neuron count is fixed by the header.
